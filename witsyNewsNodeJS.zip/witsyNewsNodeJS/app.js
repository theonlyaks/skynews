const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const routes = require('./routes/routes');
const Event = require('./models/event');
const EventBrief = require('./models/event_brief');
var nodemailer = require('nodemailer');
var hbs = require('nodemailer-express-handlebars');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json())


var http = require('http').Server(app);

mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/witsyNews');


app.use(bodyParser.json());

routes(app);


app.use((err,req,res,next)=>{
  res.status(422)
  .send({error: err.message});
});



module.exports = http;
