const env = {
	AWS_ACCESS_KEY: 'AKIA42BLSRJAHC2F6BNS',
	AWS_SECRET_ACCESS_KEY: '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',
	REGION : 'us-east-2',
	Bucket: 'vue-real-aks/images'
};

module.exports = env;