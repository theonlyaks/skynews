const Profiles = require('../models/profiles');
const randomstring = require('randomstring');
const dateTime = require('date-time');
var nodemailer = require('nodemailer');


module.exports = {
    create_account(req,res,next)
    {
      Profiles.findOne({email:req.body.email}).limit(1)
      .then((data)=>{
        if(data===null)
        {
            Profiles.create({
                user_id:randomstring.generate(),
                password:req.body.password,
                email:req.body.email,
              })
              .then(profiles => res.send(profiles));        }
        else
        {
          res.send(data);
        }
		  })
      .catch(next);
    }

};
