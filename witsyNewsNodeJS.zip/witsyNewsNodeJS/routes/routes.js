const Controller = require('../controllers/controller');
let upload = require('../config/multer.config.js');
let express = require('express');
let router = express.Router();



module.exports = (app) => {
  app.post('/api/news_witsy/create_account',Controller.create_account);
};
