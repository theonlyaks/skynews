<template>
  <div>
    <b-navbar toggleable="lg" type="dark" variant="primary">
      <div class="container">
        <b-navbar-brand @click="hapuse_nav" href="#">Hapuse   <b-badge variant="warning">Beta</b-badge></b-navbar-brand>

        <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

        <b-collapse id="nav-collapse" is-nav>

          <!-- Right aligned nav items -->
          <b-navbar-nav class="ml-auto">

            <b-nav-item-dropdown right>
              <!-- Using 'button-content' slot -->
              <template slot="button-content"><span style="color: white;">
                    <b-img :src="picture" rounded="circle" alt="Circle image" height="50px" width="50px"></b-img>
              </template>
              <b-dropdown-item href="#" @click="signOut">Logout
              </b-dropdown-item>
            </b-nav-item-dropdown>
          </b-navbar-nav>
        </b-collapse>
      </div>
    </b-navbar>
  </div>
</template>

<script>

    export default {
        name: "Navbar"
    }
</script>

<style scoped>

</style>
