<template>
      <div class="container">

          <b-row class="text-center d-flex justify-content-center">
 
    <b-col cols="5">
 <div class="newsFeed">
            
            <img class="news_feed_image" src="https://ichef.bbci.co.uk/images/ic/1024x576/p07nbg9k.jpg" height="200px" width="100%"/>
            <p class="news_feed_title">
                {{title}}
            </p>
           
          </div>
    </b-col>
 
  </b-row>

         

      </div>

</template>

<script>

  export default {
      data(){
          return {
              image:'',
              title:'',
              url:''
          }
      }
    }
</script>

<style scoped>
  .news_feed_title
  {
      font-weight: bolder;
      font-size: 30px;
  }
  .news_feed
  {
      border:solid gray 2px;
      box-shadow: 1px gray;
  }
</style>
