<template>
    <div>
        <div class="sidenav">

  <a href="#about">Sky News</a>

  <a href="#about" @click="home">Home</a>
  <a href="#services" @click="saved">Saved</a>
  <a href="#clients" @click="logout">Logout</a>
</div>
      <div class="container">
          <h1 class="text-center">Headlines</h1>
    <b-row  v-for="item in items" :key="item.title" class="text-center d-flex justify-content-center">
 
        <b-col cols="5">
            <div class="newsFeed"><a :href="item.url" tragrt="_blank" style="text-decoration:none;">
            
            <img class="news_feed_image" :src="item.urlToImage" height="200px" width="100%"/>
            <p class="news_feed_title">
                {{item.title}}
            </p>
            </a>
              <b-button style="width:100%;" @click="notify">Save</b-button>
            </div>
        </b-col>
 
    </b-row>

         

      </div>
    </div>
</template>

<script>
  import Navbar from '@/components/home/Navbar.vue';
  import Feed from '@/components/Feed.vue';
    import axios from 'axios'


  export default {
      data() {
        return {
          items: null
        }
      },
       created(){
       
        axios.get('https://newsapi.org/v2/top-headlines?country=us&apiKey=57fdf9a197e34e1c85e745dd78f581f2')
        .then((result) =>{ 
            console.log(result);
           this.items= result.data.articles;
        


          })  
        .catch(e => console.log(e));
    },
       components:{
          Navbar,
          Feed
        },

        methods:{
            home(){
window.location.replace("/home");

            },
            saved(){
// Simulate an HTTP redirect:
window.location.replace("/save");
            },
            logout(){
window.location.replace("/");

            },
            notify()
            {
                alert('Saved!');
            }
        }
    }
</script>

<style scoped>
  .news_feed_title
  {
      font-weight: bolder;
      font-size: 25px;
  }
  .news_feed_image
  {
      border-radius: 10px;
  }
  .newsFeed
  {
      border:solid gray 1px;
      box-shadow: 1px gray;
      margin:10px;
      cursor: pointer;
      border-radius: 10px;
  }
  .newsFeed:hover
  {
      background-color: whitesmoke;
  }

  .sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
