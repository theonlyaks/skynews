<template>
  <div class="container">
    <div>
      <logo />
      <h1 class="title">
        Sky News
      </h1>
      <h2 class="subtitle">
        My priceless Nuxt.js assingment
      </h2>

    <div>
            <b-form-input type="email" id="input-large" size="md" placeholder="Email"></b-form-input>
            <br/>
            <b-form-input type="password" id="input-large" size="md" placeholder="Password"></b-form-input>
    </div>
      <div class="links">
        <button  class="button--green" @click="login">
          Login
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import Logo from '~/components/Logo.vue'

export default {
  components: {
    Logo
  },
  methods:
  {
    login(){
window.location.replace("/home");
    }
  }
}
</script>

<style>
.container {
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.title {
  font-family: 'Quicksand', 'Source Sans Pro', -apple-system, BlinkMacSystemFont,
    'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}

.subtitle {
  font-weight: 300;
  font-size: 42px;
  color: #526488;
  word-spacing: 5px;
  padding-bottom: 15px;
}

.links {
  padding-top: 15px;
}
</style>
